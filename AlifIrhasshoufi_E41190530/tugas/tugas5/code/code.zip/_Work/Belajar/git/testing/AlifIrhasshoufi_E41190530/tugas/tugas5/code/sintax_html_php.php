<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo "Belajar PHP";?></title>
</head>
<body>
    <?php 

        echo "
        <pre>
saya sedang belajar PHP
belajar PHP hingga saya bisa mendapatkan uang
        </pre>
        ";

    ?>

</body>
</html>