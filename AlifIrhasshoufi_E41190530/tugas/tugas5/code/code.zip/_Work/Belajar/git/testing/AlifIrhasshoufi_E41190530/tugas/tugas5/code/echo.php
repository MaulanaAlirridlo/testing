<?php

    echo "<h2> belajar PHP itu mudah!</h2>";
    echo ("hello world<br>");
    echo "aku sedang belajar PHP<br>";
    echo "ini", "teks", "yang", "dibuat", "terpisah";

?>