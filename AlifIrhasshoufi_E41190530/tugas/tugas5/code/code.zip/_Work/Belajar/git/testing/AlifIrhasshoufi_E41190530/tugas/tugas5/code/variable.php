<?php

    $nama_barang = "minyak goreng";
    $harga = 15000;

    echo "ibu membeli $nama_barang seharga $harga";

?>