<?php

    $jenis_kelamin = 'L';
    $nama_lengkap = "nama lengkap";
    $umur = 20;
    $berat = 48.3;
    $tinggi = 182.6;
    $menikah = false;

    echo gettype($jenis_kelamin) . "<br>";
    echo gettype($nama_lengkap) . "<br>";
    echo gettype($umur) . "<br>";
    echo gettype($berat) . "<br>";
    echo gettype($tinggi) . "<br>";
    echo gettype($menikah) . "<br>";


?>