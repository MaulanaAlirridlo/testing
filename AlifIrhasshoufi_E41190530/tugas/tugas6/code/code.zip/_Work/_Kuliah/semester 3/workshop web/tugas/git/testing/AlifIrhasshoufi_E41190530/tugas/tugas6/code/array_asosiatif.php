<?php

$salaries = [
    "orang 1" => 3000,
    "orang 2" => 4000,
    "orang 3" => 5000,
];

echo $salaries["orang 1"];
echo $salaries["orang 2"];
echo $salaries["orang 3"];