<h2>sintax_php.php</h2>
<hr>

<?php include "sintax_php.php"; ?>

<h2>sintax_php.php</h2>
<hr>
<?php include "sintax_html_php.php"; ?>

<h2>sintax_php.php</h2>
<hr>
<?php include "sintax_php_html.php"; ?>

<h2>echo.php</h2>
<hr>
<?php include "echo.php"; ?>

<h2>print.php</h2>
<hr>
<?php include "print.php"; ?>

<h2>variable.php</h2>
<hr>
<?php include "variable.php"; ?>

<h2>tipe_data.php</h2>
<hr>
<?php include "tipe_data.php"; ?>

<h2>constanta.php</h2>
<hr>
<?php include "constanta.php"; ?>

<h2>operator.php</h2>
<hr>
<?php include "operator.php"; ?>