<?php

    define('VERSION', '1.0.0');

    const SITE_NAME = "coba page";
    const BASE_URL = "www.google.com";

    echo "site name : ". SITE_NAME . "<br>";
    echo "versi : ". VERSION . "<br>";
    echo "base url : ". BASE_URL . "<br>";


?>