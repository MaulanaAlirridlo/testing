<?php

echo "

<!DOCTYPE html>
<html>
<head>
    <title>Document</title>
</head>
<body>
selamat datang    
</body>
</html>

";
?>
