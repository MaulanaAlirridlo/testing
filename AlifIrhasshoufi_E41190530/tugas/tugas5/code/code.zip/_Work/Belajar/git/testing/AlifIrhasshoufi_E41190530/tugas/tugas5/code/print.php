<?php

    print "<h2> belajar PHP itu mudah!</h2>";
    print ("hello world<br>");
    print "aku sedang belajar PHP<br>";
    print "ini". "teks". "yang". "dibuat". "terpisah";

?>