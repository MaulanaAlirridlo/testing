<?php

$a = 5;
$b = 4;

// 2. Arithmetic operations
echo $a + $b . '<br>';
echo $a - $b . '<br>';
echo $a * $b . '<br>'; // 3. Several arithmetic operations - (* $c + 6)
echo $a / $b . '<br>';
echo $a % $b . '<br>';
echo $a ** $b . '<br>';

?>